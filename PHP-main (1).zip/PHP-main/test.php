<!-- <form  method="post">
<!-- <form  method="GET"> -->
    <!-- <input type="text" name="val">
    <input type="submit" >
</form> -->
<?php 
// $n = 2;
// $result = "Liczba " . $n;
// echo $n%2 ?  $result . " nie jest parzysta. 🤣❤❤❤🤣": $result . "jest parzysta.🤸‍♀️🚵‍♂️🤸‍♀️🚵‍♂️🚵‍♂️🤸‍♀️🚵‍♂️🚵‍♂️";
// $x = 10 ;
// for ($i = 1; $i <= 10; $i++){
//     echo "$i (*/ω＼*)(*/ω＼*)$x</br>" ;
//     --$x;
// };
// $endLine =  "</br>";
// echo $endLine;
// for ($i = 1; $i <= 10; $i++){
//     $y = 11 - $i;
//     echo "$i ༼ つ ◕_◕ ༽つ༼ つ ◕_◕ ༽つ(☞ﾟヮﾟ)☞☜(ﾟヮﾟ☜)$y</br>" ;

// };
// for ($i = 1; $i <= 10; $i++){
//     $y = 11 - $i;
//     echo "$i ༼ つ ◕_◕ ༽つ༼ つ ◕_◕ ༽つ(☞ﾟヮﾟ)☞☜(ﾟヮﾟ☜)$y</br>" ;

// };
// for ($i = 1; $i <= 10; $i++){
//     $y = 11 - $i;
//     echo "$i ༼ つ ◕_◕ ༽つ༼ つ ◕_◕ ༽つ(☞ﾟヮﾟ)☞☜(ﾟヮﾟ☜)$y</br>" ;

// };
// echo $endLine;
// $i = 0;
// while($i <= 10){
//     echo "$i ☆*: .｡. o(≧▽≦)o .｡.:*☆☆*: .｡. o(≧▽≦)o .｡.:*☆$y</br>" ;
//     $i++;
// }
// $i = 0;
// if(isset($_GET['val'])){
//     while($i <= $_GET['val']){
//         echo "$i</br>" ;
//         $i++;
//     }
// }
// $i = 0;
// if(isset($_POST['val'])){
//     while($i <= $_POST['val']){
//         echo "$i</br>" ;
        
//         $i++;
//     }
// }