<?php
$text = "tekst do zmiany";
$splited = str_split($text);
// echo $text;
// print_r($text);
$len = 0;
$strl = "";
for ($i=0; $i < strlen($text); $i++) { 
  if ($text[$i] != " ") {
    
  }
}
echo $strl;