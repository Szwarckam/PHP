<?php
// phpinfo();
define("PI", 3.14);
$r=2;
  echo (2*PI*$r);
  echo ("tEKSKA </br> FAFFAS");
?>